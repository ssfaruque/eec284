data = xlsread('heart.xlsx'); 

t = linspace(0,4,4000);

Fs = 1000;
L = 4 * 1000;

f = Fs*(0:L-1)/L;

y = abs(fft(data));

plot(f, y)
