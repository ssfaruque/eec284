//*****************************************************************************
//
// Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/ 
// 
// 
//  Redistribution and use in source and binary forms, with or without 
//  modification, are permitted provided that the following conditions 
//  are met:
//
//    Redistributions of source code must retain the above copyright 
//    notice, this list of conditions and the following disclaimer.
//
//    Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the 
//    documentation and/or other materials provided with the   
//    distribution.
//
//    Neither the name of Texas Instruments Incorporated nor the names of
//    its contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
//  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
//  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//*****************************************************************************

//*****************************************************************************
//
// Application Name     - Blinky
// Application Overview - The objective of this application is to showcase the 
//                        GPIO control using Driverlib api calls. The LEDs 
//                        connected to the GPIOs on the LP are used to indicate 
//                        the GPIO output. The GPIOs are driven high-low 
//                        periodically in order to turn on-off the LEDs.
// Application Details  -
// http://processors.wiki.ti.com/index.php/CC32xx_Blinky_Application
// or
// docs\examples\CC32xx_Blinky_Application.pdf
//
//*****************************************************************************

//****************************************************************************
//
//! \addtogroup blinky
//! @{
//
//****************************************************************************

// Standard includes
#include <stdio.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "interrupt.h"
#include "hw_apps_rcm.h"
#include "prcm.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "gpio.h"
#include "utils.h"
#include "timer.h"

// Common interface includes
#include "gpio_if.h"
#include "timer_if.h"

#include "pin_mux_config.h"

#define APPLICATION_VERSION     "1.1.1"

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif
//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************


//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES                           
//*****************************************************************************
void LEDBlinkyRoutine();
static void BoardInit(void);

//*****************************************************************************
//                      LOCAL FUNCTION DEFINITIONS                         
//*****************************************************************************


//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
    //
    // Set vector table base
    //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}


/************************************************************************/
/*                            Globals/Constants                         */
/************************************************************************/

// Boolean constants
#define TRUE  1
#define FALSE 0

// data types for convenience
typedef unsigned int  uint;
typedef unsigned char uchar;

// global variables/constants related to the motor
#define NUM_MOTOR_VALS 4
#define WRITES_PER_REVOLUTION 48
uchar motorVals[] = {0xa, 0x9, 0x5, 0x6};
uint rps = 1;

// global variables/constants related to heart rate
uint userHeartRate1 = 0;
uint userHeartRate2 = 0;

/************************************************************************/
/*                                                                      */
/************************************************************************/


// writes first four LSB bits of an 8 bit number to input lines of motor
void writeMotorVal(char val)
{
    // line1 is MSB and line4 is LSB
    char line1 = (0x8 & val) >> 3;
    char line2 = (0x4 & val) >> 2;
    char line3 = (0x2 & val) >> 1;
    char line4 = (0x1 & val);

    line1 = (line1 == 1) ? 0x4 : 0;
    line2 = (line2 == 1) ? 0x8 : 0;
    line3 = (line3 == 1) ? 0x10 : 0;
    line4 = (line4 == 1) ? 0x20 : 0;

    GPIOPinWrite(GPIOA1_BASE, 0x4,  line1);
    GPIOPinWrite(GPIOA1_BASE, 0x8,  line2);
    GPIOPinWrite(GPIOA1_BASE, 0x10, line3);
    GPIOPinWrite(GPIOA1_BASE, 0x20, line4);
}


/*
 * Use timer interrupt for moving motor at a specified rps
 * When you want to move motor at slower/faster rate, reload
 * timer interrupt at different rate
 *
 * Have interrupt always just rotate motor 1/48th the way.
 * 48 calls to the interrupt will result in 1 full rotation
 *
 */
void motorTimerInt()
{
    Timer_IF_InterruptClear(TIMERA0_BASE);

    static uchar index = 0;

    if(index >= NUM_MOTOR_VALS)
        index = 0;

    writeMotorVal(motorVals[index++]);
}


// reloads timer interrupt for motor at a different rate
void updateMotorSpeed(uint p_rps)
{
    rps = p_rps;
    uint time = (1000 / (WRITES_PER_REVOLUTION * rps));
    Timer_IF_ReLoad(TIMERA0_BASE, TIMER_A, time);
}


// Initialize the timer interrupts
void timerIntInit()
{
    // Configuring the timers
    Timer_IF_Init(PRCM_TIMERA0, TIMERA0_BASE, TIMER_CFG_PERIODIC, TIMER_A, 0);

    // Setup the interrupts for the timer timeouts.
    Timer_IF_IntSetup(TIMERA0_BASE, TIMER_A, motorTimerInt);

    // Turn on the timers feeding values in mSec
    uint time = (1000 / (WRITES_PER_REVOLUTION * rps));
    Timer_IF_Start(TIMERA0_BASE, TIMER_A, time);
}


int main()
{
    // Initializations
    BoardInit();
    PinMuxConfig();
    timerIntInit();

    /* Timer interrupt is moving the motor */
    while(TRUE);

    return 0;
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
