//*****************************************************************************
//
// Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/ 
// 
// 
//  Redistribution and use in source and binary forms, with or without 
//  modification, are permitted provided that the following conditions 
//  are met:
//
//    Redistributions of source code must retain the above copyright 
//    notice, this list of conditions and the following disclaimer.
//
//    Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the 
//    documentation and/or other materials provided with the   
//    distribution.
//
//    Neither the name of Texas Instruments Incorporated nor the names of
//    its contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
//  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
//  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//*****************************************************************************

//*****************************************************************************
//
// Application Name     - Blinky
// Application Overview - The objective of this application is to showcase the 
//                        GPIO control using Driverlib api calls. The LEDs 
//                        connected to the GPIOs on the LP are used to indicate 
//                        the GPIO output. The GPIOs are driven high-low 
//                        periodically in order to turn on-off the LEDs.
// Application Details  -
// http://processors.wiki.ti.com/index.php/CC32xx_Blinky_Application
// or
// docs\examples\CC32xx_Blinky_Application.pdf
//
//*****************************************************************************

//****************************************************************************
//
//! \addtogroup blinky
//! @{
//
//****************************************************************************

// Standard includes
#include <stdio.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "interrupt.h"
#include "hw_apps_rcm.h"
#include "prcm.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "gpio.h"
#include "utils.h"
#include "timer.h"
#include "uart.h"
#include "spi.h"

// Common interface includes
#include "gpio_if.h"
#include "timer_if.h"
#include "uart_if.h"

#include "pin_mux_config.h"

#include "_kiss_fft_guts.h"
//#include "kiss_fft.h"

#include <math.h>

#define APPLICATION_VERSION     "1.1.1"

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif
//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************


//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES                           
//*****************************************************************************
void LEDBlinkyRoutine();
static void BoardInit(void);

//*****************************************************************************
//                      LOCAL FUNCTION DEFINITIONS                         
//*****************************************************************************


//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
    //
    // Set vector table base
    //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}


/************************************************************************/
/*                            Globals/Constants                         */
/************************************************************************/

// Boolean constants
#define TRUE  1
#define FALSE 0

// data types for convenience
typedef unsigned int   uint;
typedef unsigned char  uchar;
typedef unsigned short ushort;

// global variables/constants related to the motor
#define NUM_MOTOR_VALS 4
#define WRITES_PER_REVOLUTION 48
uchar motorVals[] = {0xa, 0x9, 0x5, 0x6};
uint rps = 1;

// global variables/constants related to heart rate
uint userHeartRate1 = 0;
uint userHeartRate2 = 0;

#define SAMPLE_BUFFER_SIZE 4000     // # of samples
#define TOTAL_SAMPLE_TIME  20000    // time in ms

//ushort sampleBuffer1[SAMPLE_BUFFER_SIZE];
ushort sample1 = 0;
uint index1 = 0;

kiss_fft_cpx user1Sample[SAMPLE_BUFFER_SIZE];
kiss_fft_cpx user1SampleFFT[SAMPLE_BUFFER_SIZE];

kiss_fft_cpx user2Sample[SAMPLE_BUFFER_SIZE];
kiss_fft_cpx user2SampleFFT[SAMPLE_BUFFER_SIZE];


//ushort sampleBuffer2[SAMPLE_BUFFER_SIZE];
ushort sample2 = 0;
uint index2 = 0;

// other variables
uchar ADC_bits[2];

#define SPI_IF_BIT_RATE  300000

/************************************************************************/
/*                                                                      */
/************************************************************************/




// writes first four LSB bits of an 8 bit number to input lines of motor
void writeMotorVal(char val)
{
    // line1 is MSB and line4 is LSB
    char line1 = (0x8 & val) >> 3;
    char line2 = (0x4 & val) >> 2;
    char line3 = (0x2 & val) >> 1;
    char line4 = (0x1 & val);

    line1 = (line1 == 1) ? 0x4 : 0;
    line2 = (line2 == 1) ? 0x8 : 0;
    line3 = (line3 == 1) ? 0x10 : 0;
    line4 = (line4 == 1) ? 0x20 : 0;

    GPIOPinWrite(GPIOA1_BASE, 0x4,  line1);
    GPIOPinWrite(GPIOA1_BASE, 0x8,  line2);
    GPIOPinWrite(GPIOA1_BASE, 0x10, line3);
    GPIOPinWrite(GPIOA1_BASE, 0x20, line4);
}


/*
 * Use timer interrupt for moving motor at a specified rps
 * When you want to move motor at slower/faster rate, reload
 * timer interrupt at different rate
 *
 * Have interrupt always just rotate motor 1/48th the way.
 * 48 calls to the interrupt will result in 1 full rotation
 *
 */
void motorTimerInt()
{
    Timer_IF_InterruptClear(TIMERA0_BASE);

    static uchar index = 0;

    if(index >= NUM_MOTOR_VALS)
        index = 0;

    writeMotorVal(motorVals[index++]);
}


// reloads timer interrupt for motor at a different rate
void updateMotorSpeed(uint p_rps)
{
    rps = p_rps;
    uint time = (1000 / (WRITES_PER_REVOLUTION * rps));
    Timer_IF_ReLoad(TIMERA0_BASE, TIMER_A, time);
}


void sampleHeartRateInt()
{
    Timer_IF_InterruptClear(TIMERA2_BASE);

    if(index1 < SAMPLE_BUFFER_SIZE)
    {
        // chip select low to start reading
        GPIOPinWrite(GPIOA2_BASE, 0x2, 0);

        long returnStatus = SPITransfer(GSPI_BASE,
                                         0,
                                         ADC_bits,
                                         2 * sizeof(uchar),
                                         SPI_CS_ENABLE | SPI_CS_DISABLE);

        // chip select high to stop reading
        GPIOPinWrite(GPIOA2_BASE, 0x2, 0x2);


        // ADC_bits[0] is most significant byte
        short bitVal =  (((ADC_bits[0] & 0x001f) << 5) | ((ADC_bits[1] & 0x00f8) >> 3));

        user1Sample[index1].r = (float)bitVal;
        user1Sample[index1++].i =  0;

    }
}


void measureHeartRateInt()
{
    MAP_TimerIntDisable(TIMERA2_BASE, TIMER_TIMA_TIMEOUT);
    Timer_IF_InterruptClear(TIMERA1_BASE);

    // nfft = number of samples
    kiss_fft_cfg cfg = kiss_fft_alloc(SAMPLE_BUFFER_SIZE, 0, 0, 0);
    kiss_fft(cfg, user1Sample, user1SampleFFT);
    free(cfg);

    int i;

    for(i = 0; i < SAMPLE_BUFFER_SIZE; ++i)
    {
        user1SampleFFT[i].r = (user1SampleFFT[i].r * user1SampleFFT[i].r)
                            + (user1SampleFFT[i].i * user1SampleFFT[i].i);
    }


    uint lowIndex = (0.883f / 0.05f);
    uint highIndex = (3.0f / 0.05f);

    ushort indexOfMaxAmp1 = lowIndex, indexOfMaxAmp2 = lowIndex;
    float max1 = 0.0f, max2 = 0.0f;


    for(i = lowIndex; i <= highIndex; ++i)
    {
        if(user1SampleFFT[i].r > max1)
        {
            max1 = user1SampleFFT[i].r;
            indexOfMaxAmp1 = i;
        }
    }


    for(i = lowIndex; i < indexOfMaxAmp1 - 4; ++i)
    {
        if(user1SampleFFT[i].r > max2 && i != indexOfMaxAmp1)
        {
            max2 = user1SampleFFT[i].r;
            indexOfMaxAmp2 = i;
        }

    }

    userHeartRate1 = 60.0f * ((float)(indexOfMaxAmp1) * 0.05f);
    userHeartRate2 = 60.0f * ((float)(indexOfMaxAmp2) * 0.05f);

    Report("Heart Rate 1: %d bpm\n\r", userHeartRate1);
    Report("Heart Rate 2: %d bpm\n\r", userHeartRate2);

    index1 = 0;

    MAP_TimerIntEnable(TIMERA2_BASE, TIMER_TIMA_TIMEOUT);
}


// Initialize the timer interrupts
void timerIntInit()
{
    /***** Configuring the timers *****/

    // for motor
    //Timer_IF_Init(PRCM_TIMERA0, TIMERA0_BASE, TIMER_CFG_PERIODIC, TIMER_A, 0);

    // for measuring heart rate
    Timer_IF_Init(PRCM_TIMERA1, TIMERA1_BASE, TIMER_CFG_PERIODIC, TIMER_A, 0);

    // for sampling heart rate
    Timer_IF_Init(PRCM_TIMERA2, TIMERA2_BASE, TIMER_CFG_PERIODIC, TIMER_A, 0);


    /***** Setup the interrupts for the timer timeouts *****/

    // for motor
    //Timer_IF_IntSetup(TIMERA0_BASE, TIMER_A, motorTimerInt);

    // for measuring heart rate
    Timer_IF_IntSetup(TIMERA1_BASE, TIMER_A, measureHeartRateInt);

    // for sampling heart rate
    Timer_IF_IntSetup(TIMERA2_BASE, TIMER_A, sampleHeartRateInt);


    /***** Turn on the timers feeding values in mSec *****/

    // for motor
    uint time = (1000 / (WRITES_PER_REVOLUTION * rps));
    //Timer_IF_Start(TIMERA0_BASE, TIMER_A, time);

    // for measuring heart rate (every 20 seconds)
    Timer_IF_Start(TIMERA1_BASE, TIMER_A, TOTAL_SAMPLE_TIME);

    // for sampling heart rate
    Timer_IF_Start(TIMERA2_BASE, TIMER_A, 5);
}


void initSPI()
{
    // Enable the SPI module clock
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);

    // Reset the peripheral
    MAP_PRCMPeripheralReset(PRCM_GSPI);

    // Reset SPI
    MAP_SPIReset(GSPI_BASE);

    // Configure SPI interface
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                     SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_0,
                     (SPI_SW_CTRL_CS |
                     SPI_4PIN_MODE |
                     SPI_TURBO_OFF |
                     SPI_CS_ACTIVELOW |
                     SPI_WL_8));

    // Enable SPI for communication
    MAP_SPIEnable(GSPI_BASE);

    // Chip Select for ADC High
    GPIOPinWrite(GPIOA2_BASE, 0x2, 0x2);
}


int main()
    {
    // Initializations
    BoardInit();
    PinMuxConfig();
    timerIntInit();
    initSPI();
    InitTerm();
    ClearTerm();


    while(TRUE)
    {
    }

    return 0;
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
